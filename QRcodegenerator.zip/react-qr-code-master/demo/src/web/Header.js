import styled from "styled-components";

export default styled.header`
  margin-bottom: 3rem;
  text-align: center;
`;
