import styled from "styled-components";

export default styled.main`
  margin: 3rem auto;
  max-width: 650px;
  padding: 0 25px;
`;
