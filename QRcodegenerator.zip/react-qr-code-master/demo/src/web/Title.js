import styled from "styled-components";

export default styled.h1`
  font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
  font-size: 46px;
  margin-bottom: 3rem;
  letter-spacing: -1px;
`;
