import styled from "styled-components";

export default styled.p`
  font-size: 15px;
  color: #111;
`;
