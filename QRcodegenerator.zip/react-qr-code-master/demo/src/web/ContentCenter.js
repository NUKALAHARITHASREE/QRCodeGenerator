import styled from "styled-components";

export default styled.main`
  text-align: center;
`;
