import styled from "styled-components";

export default styled.footer`
  color: #999;
  font-size: 12px;
  line-height: 2;
  margin-top: 5rem;
  text-align: center;
`;
