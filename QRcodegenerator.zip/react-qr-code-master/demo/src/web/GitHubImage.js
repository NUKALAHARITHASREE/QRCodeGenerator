import styled from "styled-components";

export default styled.img`
  position: absolute;
  top: 0;
  right: 0;
  border: 0;
`;
