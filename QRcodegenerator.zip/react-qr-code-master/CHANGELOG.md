# Changelog

## [2.0.15](https://github.com/rosskhanas/react-qr-code/compare/2.0.14...2.0.15) (2024-06-20)

### Bug Fixes

* remove react-native-svg from peerDependencies
